makoto-pet firmware flashing
============================

Option A (recommended): flash the merged image at address 0x0

  esptool.py --chip esp32s3 -p COM15 -b 460800 write_flash 0x0 merged-binary.bin

Option B: flash the three images separately

  esptool.py --chip esp32s3 -p COM15 -b 460800 write_flash 
      0x0     bootloader.bin 
      0x8000  partition-table.bin 
      0x10000 makoto_pet.bin

Replace COM15 with your port. After flashing, the board starts in Wi-Fi
provisioning mode (AP "Makoto-Pet-XXXX", password makoto1234).
